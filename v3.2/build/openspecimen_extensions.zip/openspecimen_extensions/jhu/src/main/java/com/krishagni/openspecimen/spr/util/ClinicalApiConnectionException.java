package com.krishagni.openspecimen.spr.util;

public class ClinicalApiConnectionException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ClinicalApiConnectionException(String message) {
		super(message);
	}

}
