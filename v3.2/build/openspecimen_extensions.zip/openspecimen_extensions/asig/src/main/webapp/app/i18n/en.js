{
  "participant": {
    "ppid": "ASIG ID",
    "death_date": "Last Contact Date",
    "vital_status": "Status in Research",
    "pmis": "Sites"
  }
}
