
package com.krishagni.catissueplus.core.common.util;

public enum ObjectType {
	PARTICIPANT;
}
