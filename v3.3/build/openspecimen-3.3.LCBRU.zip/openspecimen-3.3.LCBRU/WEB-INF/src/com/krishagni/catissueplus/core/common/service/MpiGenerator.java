
package com.krishagni.catissueplus.core.common.service;

public interface MpiGenerator {
	public String generateMpi();
}
