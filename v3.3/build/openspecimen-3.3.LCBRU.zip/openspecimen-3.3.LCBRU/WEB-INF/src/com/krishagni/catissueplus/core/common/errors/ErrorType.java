
package com.krishagni.catissueplus.core.common.errors;

public enum ErrorType {
	NONE,
	
	SYSTEM_ERROR,
	
	USER_ERROR,
	
	UNKNOWN_ERROR
}
