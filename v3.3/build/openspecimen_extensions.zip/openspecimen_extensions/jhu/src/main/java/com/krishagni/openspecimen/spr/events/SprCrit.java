package com.krishagni.openspecimen.spr.events;


public class SprCrit {

	private String mrn;

	public String getMrn() {
		return mrn;
	}

	public void setMrn(String mrn) {
		this.mrn = mrn;
	}
	
}
