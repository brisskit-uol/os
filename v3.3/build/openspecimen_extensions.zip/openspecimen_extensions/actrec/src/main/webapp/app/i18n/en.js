{
  "participant": {
    "ppid": "Animal ID",
    "category": "Category",
    "breed": "Breed",
    "colour": "Colour"
  }
}
