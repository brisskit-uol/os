
package com.krishagni.catissueplus.core.common.errors;

public interface ErrorCode {
	public String code();
}
