package com.krishagni.rbac.repository;

import com.krishagni.catissueplus.core.common.events.AbstractListCriteria;

public class PermissionListCriteria extends AbstractListCriteria<PermissionListCriteria> {

	@Override
	public PermissionListCriteria self() {
		return this;
	}

}
