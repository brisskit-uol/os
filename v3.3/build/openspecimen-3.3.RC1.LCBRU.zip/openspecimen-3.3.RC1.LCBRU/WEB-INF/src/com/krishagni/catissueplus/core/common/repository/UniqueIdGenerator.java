package com.krishagni.catissueplus.core.common.repository;

public interface UniqueIdGenerator {
	public Long getUniqueId(String type, String id);
}
