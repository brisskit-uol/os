package com.krishagni.rbac.repository;

import com.krishagni.catissueplus.core.common.events.AbstractListCriteria;

public class OperationListCriteria extends AbstractListCriteria<OperationListCriteria> {

	@Override
	public OperationListCriteria self() {
		return this;
	}

}
