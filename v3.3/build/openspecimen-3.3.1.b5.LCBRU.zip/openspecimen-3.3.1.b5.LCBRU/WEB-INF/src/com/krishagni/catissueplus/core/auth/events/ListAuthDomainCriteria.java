
package com.krishagni.catissueplus.core.auth.events;

import com.krishagni.catissueplus.core.common.events.AbstractListCriteria;

public class ListAuthDomainCriteria extends AbstractListCriteria<ListAuthDomainCriteria> {

	@Override
	public ListAuthDomainCriteria self() {
		return this;
	}

}
