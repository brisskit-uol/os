package com.krishagni.catissueplus.core.support.events;

public class FeedbackDetail {
	private String subject;
	
	private String feedback;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
}
