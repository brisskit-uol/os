Steps to deploy OpenSpecimen
1. Please fill up the properties.varfile
2. Make sure 'openspecimen.sh' has executable rights. Run the below command: ./openspecimen.sh -q -varfile <path to properties.varfile>
