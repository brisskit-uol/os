package com.krishagni.catissueplus.core.common.service;

public interface ObjectStateParamsResolverFactory {
	public ObjectStateParamsResolver getResolver(String objectName);
}
