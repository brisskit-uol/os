package com.krishagni.rbac.repository;

import com.krishagni.catissueplus.core.common.events.AbstractListCriteria;

public class ResourceListCriteria extends AbstractListCriteria<ResourceListCriteria> {

	@Override
	public ResourceListCriteria self() {
		return this;
	}

}
