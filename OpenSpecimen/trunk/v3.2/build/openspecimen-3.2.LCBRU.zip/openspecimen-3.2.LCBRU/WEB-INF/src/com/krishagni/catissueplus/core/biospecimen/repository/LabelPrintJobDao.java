package com.krishagni.catissueplus.core.biospecimen.repository;

import com.krishagni.catissueplus.core.common.domain.LabelPrintJob;
import com.krishagni.catissueplus.core.common.repository.Dao;

public interface LabelPrintJobDao extends Dao<LabelPrintJob> {

}
