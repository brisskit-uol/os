package com.krishagni.catissueplus.core.common.service;

public interface ConfigChangeListener {
	public void onConfigChange(String name, String value);
}
