package com.krishagni.openspecimen.sgh.services;


public interface TridGenerator {

	public String getNextTrid();
}
