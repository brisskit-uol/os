package com.krishagni.openspecimen.asig.service;


public interface AsigService {
	
	public void createSites();

	public void createUsers();
	
	public void registerPatients();
	
}