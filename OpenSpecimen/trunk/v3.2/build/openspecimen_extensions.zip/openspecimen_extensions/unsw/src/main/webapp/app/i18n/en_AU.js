{
  "visits": {
      "menu": {
          "spr_report": "De-identified Path Report"
      }
  }
}
