package com.krishagni.catissueplus.core.de.events;

/**
 * Created by akshay on 30/6/14.
 */
public class ObjectCpDetail {

    private Long objectId;

    private Long cpId;

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public Long getCpId() {
        return cpId;
    }

    public void setCpId(Long cpId) {
        this.cpId = cpId;
    }
}
