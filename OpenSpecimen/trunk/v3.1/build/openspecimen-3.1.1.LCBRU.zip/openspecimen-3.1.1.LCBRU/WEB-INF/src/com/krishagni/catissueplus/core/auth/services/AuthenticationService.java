
package com.krishagni.catissueplus.core.auth.services;


public interface AuthenticationService {
	public void authenticate(String username, String password);
}
