package com.krishagni.catissueplus.core.biospecimen.events;

public class MergeCpDetail {
	private String srcCpShortTitle;
	
	private String tgtCpShortTitle;

	public String getSrcCpShortTitle() {
		return srcCpShortTitle;
	}

	public void setSrcCpShortTitle(String srcCpShortTitle) {
		this.srcCpShortTitle = srcCpShortTitle;
	}

	public String getTgtCpShortTitle() {
		return tgtCpShortTitle;
	}

	public void setTgtCpShortTitle(String tgtCpShortTitle) {
		this.tgtCpShortTitle = tgtCpShortTitle;
	}

}
