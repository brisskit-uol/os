
package com.krishagni.catissueplus.core.biospecimen.events;

public class ConsentTierResponseDetail {

	private String statement;
	
	private String response;

	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
}
