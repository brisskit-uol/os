package com.krishagni.rbac.repository;

import com.krishagni.catissueplus.core.common.events.AbstractListCriteria;

public class RoleListCriteria extends AbstractListCriteria<RoleListCriteria> {
	@Override
	public RoleListCriteria self() {
		return this;
	}

}
