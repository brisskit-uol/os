package com.krishagni.catissueplus.core.biospecimen.services;

public interface Anonymizer<T> {
	void anonymize(T object);
}
