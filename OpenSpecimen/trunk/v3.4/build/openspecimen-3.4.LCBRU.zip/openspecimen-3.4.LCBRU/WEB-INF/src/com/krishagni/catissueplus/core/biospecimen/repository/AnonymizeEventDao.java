package com.krishagni.catissueplus.core.biospecimen.repository;

import com.krishagni.catissueplus.core.biospecimen.domain.AnonymizeEvent;
import com.krishagni.catissueplus.core.common.repository.Dao;

public interface AnonymizeEventDao extends Dao<AnonymizeEvent> {
}
