package com.krishagni.openspecimen.epic.service;


public interface EpicService {

	public void registerParticipants();
	
}
