package com.krishagni.openspecimen.epic.util;


public enum ResponseStatus {
    ADDED,MODIFIED,ERROR,MERGEFAILED,MRNDELETED
}
