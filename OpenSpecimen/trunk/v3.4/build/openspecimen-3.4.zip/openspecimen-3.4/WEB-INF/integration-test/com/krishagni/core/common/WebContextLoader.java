package com.krishagni.core.common;

public class WebContextLoader extends GenericWebContextLoader {
	public WebContextLoader() {
        super("classes", false);
    }
}
